(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var _ = Package.underscore._;
var EJSON = Package.ejson.EJSON;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['u2622:persistent-session'] = {};

})();

//# sourceMappingURL=u2622_persistent-session.js.map
