(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Home/HomeMethods.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isServer) {                                                 // 1
  Meteor.methods({                                                     // 2
    'createGame': function () {                                        // 3
      var gameId = Games.insert({                                      // 4
        stage: 'Lobby'                                                 // 5
      });                                                              //
                                                                       //
      return gameId;                                                   // 8
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=HomeMethods.js.map
