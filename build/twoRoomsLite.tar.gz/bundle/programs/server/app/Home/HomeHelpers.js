(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Home/HomeHelpers.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
  // This code only runs on the client                                 //
  Template.home.events({                                               // 3
    "click .new-game-button": function (event) {                       // 4
      Meteor.call("createGame", function (error, gameId) {             // 5
        if (error) {                                                   // 6
          //handle error                                               //
        } else {                                                       //
            Router.go("/game/" + gameId);                              // 10
          }                                                            //
      });                                                              //
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=HomeHelpers.js.map
