(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// twoRoomsLite.js                                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
  Meteor.subscribe("Cards");                                           // 2
  Meteor.subscribe("Players");                                         // 3
  Meteor.subscribe("Games");                                           // 4
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 7
  Meteor.publish("Cards", function () {                                // 8
    return Cards.find({});                                             // 9
  });                                                                  //
  Meteor.publish("Players", function () {                              // 11
    return Players.find({});                                           // 12
  });                                                                  //
  Meteor.publish("Games", function () {                                // 14
    return Games.find({});                                             // 15
  });                                                                  //
                                                                       //
  if (Cards.find({}).count() === 0) {                                  // 18
    var bomber = {                                                     // 19
      name: "Bomber",                                                  // 20
      description: "You are the Bomber! End the game in the same room as the President, and the Terrorists win.",
      team: "Terrorists",                                              // 22
      core: true                                                       // 23
    };                                                                 //
                                                                       //
    var president = {                                                  // 26
      name: "President",                                               // 27
      description: "You are the President! End the game in a different room from the Bomber and the Counter-Terrorists win.",
      team: "Counter-Terrorists",                                      // 29
      core: true                                                       // 30
    };                                                                 //
                                                                       //
    var agent = {                                                      // 33
      name: "Agent",                                                   // 34
      description: "You are an agent of the secret service. Protect the president at all costs!",
      team: "Counter-Terrorists",                                      // 36
      core: true                                                       // 37
    };                                                                 //
                                                                       //
    var terrorist = {                                                  // 40
      name: "Terrorist",                                               // 41
      description: "You are a terrorist. You should feel ashamed of your poor life choices.",
      team: "Terrorists",                                              // 43
      core: true                                                       // 44
    };                                                                 //
                                                                       //
    var gambler = {                                                    // 47
      name: "Gambler",                                                 // 48
      description: "You must pick a side before the game is done. Better guess right!",
      team: "Individual",                                              // 50
      core: true                                                       // 51
    };                                                                 //
                                                                       //
    var terroristSpy = {                                               // 54
      name: "Terrorist Spy",                                           // 55
      description: "Shhh...you're actually a terrorist.",              // 56
      team: "Counter-Terrorists",                                      // 57
      core: false                                                      // 58
    };                                                                 //
                                                                       //
    var ctSpy = {                                                      // 61
      name: "Counter-Terrorist Spy",                                   // 62
      description: "You are a highly trained spy in a deep cover operation. Gain the enemy's trust, gather intel, and most importantly: save the President.",
      team: "Counter-Terrorists",                                      // 64
      core: false                                                      // 65
    };                                                                 //
                                                                       //
    var moby = {                                                       // 68
      name: "Moby",                                                    // 69
      description: "You are an elusive white whale that just wants to be left alone! You win the game if that pesky Captain Ahab winds up in the same room as the bomber.",
      team: "Individual",                                              // 71
      core: false                                                      // 72
    };                                                                 //
                                                                       //
    var ahab = {                                                       // 75
      name: "Ahab",                                                    // 76
      description: "You are Captain Ahab! Forever on the hunt for that darned white whale. You win the game if Moby winds up in the same room as the bomber. Let's see him swim away after that one!",
      team: "Individual",                                              // 78
      core: false                                                      // 79
    };                                                                 //
                                                                       //
    var terroristShyGuy = {                                            // 82
      name: "Shy Guy (Terrorist)",                                     // 83
      description: "You tell everyone that you're shy, but really you just don't want to share anything about yourself.",
      team: "Terrorists",                                              // 85
      core: false                                                      // 86
    };                                                                 //
                                                                       //
    var ctShyGuy = {                                                   // 89
      name: "Shy Guy (Counter-Terrorist)",                             // 90
      description: "It's not so much that you don't have anything to say, you just don't like to toot your own horn. In fact, you can't even tell anyone that you're part of the secret service.",
      team: "Counter-Terrorists",                                      // 92
      core: false                                                      // 93
    };                                                                 //
                                                                       //
    var firstLady = {                                                  // 96
      name: "First Lady",                                              // 97
      description: "You've been with him through thick and thin; this crisis doesn't change any of that. End the game in the same room as the president and you win.",
      team: "Individual",                                              // 99
      core: false                                                      // 100
    };                                                                 //
                                                                       //
    var mistress = {                                                   // 103
      name: "The other woman",                                         // 104
      description: "You've been working a lot of long hours together, and you can totally sense that there's a connection between you two. If only he wasn't married...End the game in the same room as the president (without the First Lady) to win the game.",
      team: "Individual",                                              // 106
      core: false                                                      // 107
    };                                                                 //
                                                                       //
    Cards.insert(bomber);                                              // 110
    Cards.insert(president);                                           // 111
    Cards.insert(agent);                                               // 112
    Cards.insert(terrorist);                                           // 113
    Cards.insert(gambler);                                             // 114
    Cards.insert(terroristSpy);                                        // 115
    Cards.insert(ctSpy);                                               // 116
    Cards.insert(moby);                                                // 117
    Cards.insert(ahab);                                                // 118
    Cards.insert(terroristShyGuy);                                     // 119
    Cards.insert(ctShyGuy);                                            // 120
    Cards.insert(firstLady);                                           // 121
    Cards.insert(mistress);                                            // 122
  }                                                                    //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=twoRoomsLite.js.map
