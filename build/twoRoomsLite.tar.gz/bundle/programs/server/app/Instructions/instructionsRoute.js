(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Instructions/instructionsRoute.js                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Router.route('/instructions', {                                        // 1
	template: 'instructions'                                              // 2
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=instructionsRoute.js.map
