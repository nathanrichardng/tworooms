(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Timer/TimerMethods.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isServer) {                                                 // 1
  Meteor.methods({                                                     // 2
    'startTimer': function (gameId) {                                  // 3
      var game = Games.findOne({ _id: gameId });                       // 4
      var endTime;                                                     // 5
      if (game.timerPaused) {                                          // 6
        var timeElapsed = moment().diff(moment(game.timerPausedTime));
        endTime = moment(game.timerEndTime).add(timeElapsed, "ms").toDate();
      } else if (game.timerEndTime) {                                  //
        endTime = game.timerEndTime;                                   // 11
      } else {                                                         //
        endTime = moment().add(game.timerLength, "minutes").toDate();  // 14
      }                                                                //
      Games.update({ _id: gameId }, {                                  // 16
        $set: { timerEndTime: endTime, timerPaused: false, timerPausedTime: null }
      });                                                              //
      return endTime;                                                  // 19
    },                                                                 //
    'pauseTimer': function (gameId) {                                  // 21
      var game = Games.findOne({ _id: gameId });                       // 22
      var pausedTime = moment().toDate();                              // 23
      if (game.timerPaused) {                                          // 24
        return "Already paused";                                       // 25
      }                                                                //
      Games.update({ _id: gameId }, {                                  // 27
        $set: { timerPaused: true, timerPausedTime: pausedTime }       // 28
      });                                                              //
      return pausedTime;                                               // 30
    },                                                                 //
    'resetTimer': function (gameId) {                                  // 32
      Games.update({ _id: gameId }, {                                  // 33
        $set: { timerEndTime: null, timerPaused: false, timerPausedTime: null }
      });                                                              //
      return "timer reset";                                            // 36
    },                                                                 //
    'setTimerLength': function (gameId, length) {                      // 38
      var filteredLength = length >= 0 ? length : 3;                   // 39
      Games.update({ _id: gameId }, {                                  // 40
        $set: { timerLength: filteredLength, timerEndTime: null, timerPaused: false, timerPausedTime: null }
      });                                                              //
      return "updated timer length";                                   // 43
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=TimerMethods.js.map
