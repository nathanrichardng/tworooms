(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Timer/TimerHelpers.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
                                                                       //
  Template.timer.helpers({                                             // 3
    timeRemaining: function () {                                       // 4
      var playerId = Session.get("playerId");                          // 5
      var player = Players.findOne({ _id: playerId });                 // 6
      var game = Games.findOne({ _id: player.game });                  // 7
      var endTime = game.timerEndTime;                                 // 8
      var returnTime;                                                  // 9
      if (game.timerPaused) {                                          // 10
        returnTime = moment(endTime - game.timerPausedTime);           // 11
      } else if (endTime) {                                            //
        returnTime = moment(endTime - TimeSync.serverTime(null, 500));
      } else {                                                         //
        returnTime = moment(game.timerLength * 60000);                 // 17
      }                                                                //
                                                                       //
      return returnTime > 0 ? returnTime.format("m:ss") : "Times up!";
    },                                                                 //
    timerRunning: function () {                                        // 22
      var playerId = Session.get("playerId");                          // 23
      var player = Players.findOne({ _id: playerId });                 // 24
      var game = Games.findOne({ _id: player.game });                  // 25
      return !game.timerPaused && game.timerEndTime;                   // 26
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.timer.events({                                              // 30
    "click .start-timer": function (event) {                           // 31
      event.preventDefault();                                          // 32
      Meteor.call("startTimer", this._id, function (error, time) {     // 33
        console.log("start time", time);                               // 34
      });                                                              //
    },                                                                 //
    "click .pause-timer": function (event) {                           // 37
      event.preventDefault();                                          // 38
      Meteor.call("pauseTimer", this._id, function (error, time) {     // 39
        console.log("pause time", time);                               // 40
      });                                                              //
    },                                                                 //
    "click .reset-timer": function (event) {                           // 43
      event.preventDefault();                                          // 44
      Meteor.call("resetTimer", this._id, function (error, time) {     // 45
        console.log("reset time", time);                               // 46
      });                                                              //
    },                                                                 //
    "submit .set-timer-length": function (event) {                     // 49
      event.preventDefault();                                          // 50
      console.log(event.target.timerLength.value);                     // 51
      Meteor.call("setTimerLength", this._id, event.target.timerLength.value, function (error, success) {
        console.log("set timer length", success);                      // 53
      });                                                              //
      $('#set-timer-modal').modal('toggle');                           // 55
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=TimerHelpers.js.map
