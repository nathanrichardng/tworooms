(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Players/PlayerHelpers.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
  // This code only runs on the client                                 //
  Template.players.helpers({                                           // 3
    players: function () {                                             // 4
      console.log(Games.findOne({ _id: this._id }));                   // 5
      return Players.find({ game: this._id });                         // 6
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=PlayerHelpers.js.map
