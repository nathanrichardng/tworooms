(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Game/GameHelpers.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
  // This code only runs on the client                                 //
  Template.game.helpers({                                              // 3
    inLobby: function () {                                             // 4
      return this.stage === "Lobby";                                   // 5
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.lobby.helpers({                                             // 9
    playingGame: function () {                                         // 10
      var playerId = Session.get("playerId");                          // 11
      var gameId = this._id;                                           // 12
      console.log("Session playerId", playerId);                       // 13
      if (playerId === "" || playerId === null) {                      // 14
        return false;                                                  // 15
      }                                                                //
                                                                       //
      return Players.findOne({ _id: playerId, game: gameId });         // 18
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.game.events({                                               // 22
    "submit .add-player-form": function (event) {                      // 23
      event.preventDefault();                                          // 24
      var gameId = this._id;                                           // 25
      var playerName = event.target.name.value;                        // 26
      console.log("game id", gameId);                                  // 27
      console.log("player name", playerName);                          // 28
      Meteor.call("joinGame", gameId, playerName, function (error, playerId) {
        if (error) {                                                   // 30
          console.log("error joining game", error);                    // 31
        } else {                                                       //
          Session.setPersistent("playerId", playerId);                 // 34
          console.log("Player Id", playerId);                          // 35
        }                                                              //
      });                                                              //
    },                                                                 //
    "click .leave-game-button": function (event) {                     // 39
      event.preventDefault();                                          // 40
      console.log("Leaving Game");                                     // 41
      console.log("current game", Games.findOne({ _id: this._id }));   // 42
      var playerId = Session.get("playerId");                          // 43
      Meteor.call("leaveGame", playerId, function (error, success) {   // 44
        if (error) {                                                   // 45
          console.log("error leaving game", error);                    // 46
          Router.go("/");                                              // 47
        } else {                                                       //
          console.log("successfully left game", success);              // 50
          Session.setPersistent("playerId", null);                     // 51
          Router.go("/");                                              // 52
        }                                                              //
      });                                                              //
    },                                                                 //
    "click .start-game-button": function (event) {                     // 56
      event.preventDefault();                                          // 57
      console.log("Starting Game");                                    // 58
      var gameId = this._id;                                           // 59
      Meteor.call("startGame", gameId, function (error, success) {     // 60
        if (error) {                                                   // 61
          console.log("error starting game", error);                   // 62
        } else {                                                       //
          console.log("successfully started game", success);           // 65
        }                                                              //
      });                                                              //
    },                                                                 //
    "click #game-address": function (event) {                          // 69
      var urlField = document.getElementById('game-address');          // 70
      // select the contents                                           //
      urlField.setSelectionRange(0, 9999);                             // 72
      if (document.queryCommandSupported("copy")) {                    // 73
        document.execCommand("copy");                                  // 74
      }                                                                //
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=GameHelpers.js.map
