(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Game/GameRoute.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Router.route('/game/:gameId', {                                        // 1
	template: 'game',                                                     // 2
	waitOn: function () {                                                 // 3
		return Meteor.subscribe('Games');                                    // 4
	},                                                                    //
	data: function () {                                                   // 6
		var gameId = this.params.gameId;                                     // 7
		return Games.findOne({ _id: gameId });                               // 8
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=GameRoute.js.map
