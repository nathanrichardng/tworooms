(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Game/GameMethods.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isServer) {                                                 // 1
  Meteor.methods({                                                     // 2
    'joinGame': function (gameId, playerName) {                        // 3
      var playerId = Players.insert({ game: gameId, name: playerName });
      Games.update({ _id: gameId, stage: "Lobby" }, {                  // 5
        $addToSet: { players: playerId }                               // 6
      });                                                              //
      return playerId;                                                 // 8
    },                                                                 //
    'leaveGame': function (playerId) {                                 // 10
      var player = Players.findOne({ _id: playerId });                 // 11
                                                                       //
      if (player) {                                                    // 13
        var gameId = player.game;                                      // 14
                                                                       //
        Players.remove({ _id: playerId });                             // 16
                                                                       //
        Games.update({ _id: gameId }, {                                // 18
          $pull: { players: playerId }                                 // 19
        });                                                            //
      }                                                                //
                                                                       //
      //remove all games that are at least a day old                   //
      var cutoffTime = moment().subtract(1, "days").toDate();          // 24
      Games.remove({ createdOn: { $lte: cutoffTime } });               // 25
                                                                       //
      return "Left Game";                                              // 27
    },                                                                 //
    'addCardToDeckList': function (playerId, cardId) {                 // 29
      var player = Players.findOne({ _id: playerId });                 // 30
      var gameId = player.game;                                        // 31
      var game = Games.findOne({ _id: gameId });                       // 32
      if (game.deckList.length + 2 >= game.players.length) {           // 33
        return "Not enough players";                                   // 34
      }                                                                //
      Games.update({ _id: gameId }, {                                  // 36
        $addToSet: { deckList: cardId }                                // 37
      });                                                              //
      return cardId + " was added to DeckList by " + playerId;         // 39
    },                                                                 //
    'removeCardFromDeckList': function (playerId, cardId) {            // 41
      var player = Players.findOne({ _id: playerId });                 // 42
      var gameId = player.game;                                        // 43
      Games.update({ _id: gameId }, {                                  // 44
        $pull: { deckList: cardId }                                    // 45
      });                                                              //
      return cardId + " was removed from DeckList by " + playerId;     // 47
    },                                                                 //
    'startGame': function (gameId) {                                   // 49
      var game = Games.findOne({ _id: gameId });                       // 50
      var players = Players.find({ game: gameId }).fetch();            // 51
      var playerSelectedCards = game.deckList;                         // 52
      var remainingCards = players.length;                             // 53
                                                                       //
      var deck = [];                                                   // 55
                                                                       //
      //add president and bomber                                       //
      var president = Cards.findOne({ name: "President" })._id;        // 58
      var bomber = Cards.findOne({ name: "Bomber" })._id;              // 59
      deck.push(president);                                            // 60
      deck.push(bomber);                                               // 61
      remainingCards -= 2;                                             // 62
                                                                       //
      //add the player selected cards                                  //
      if (playerSelectedCards.length > 0) {                            // 65
        for (var k = 0; k < remainingCards; k++) {                     // 66
          deck.push(playerSelectedCards[k]);                           // 67
        }                                                              //
      }                                                                //
                                                                       //
      //update the number of remaining cards                           //
      remainingCards -= playerSelectedCards.length;                    // 72
      //if there will be an odd number of players left                 //
      //add a Gambler to fill the gap                                  //
      if (remainingCards % 2 > 0) {                                    // 75
        var gambler = Cards.findOne({ name: "Gambler" })._id;          // 76
        deck.push(gambler);                                            // 77
        remainingCards -= 1;                                           // 78
      }                                                                //
                                                                       //
      //divide the remaining cards into Agent or Terrorist             //
      for (var i = 0; i < remainingCards / 2; i++) {                   // 83
        var agent = Cards.findOne({ name: "Agent" })._id;              // 84
        var terrorist = Cards.findOne({ name: "Terrorist" })._id;      // 85
        deck.push(agent);                                              // 86
        deck.push(terrorist);                                          // 87
      }                                                                //
                                                                       //
      //shuffle the deck                                               //
      shuffle(deck);                                                   // 91
                                                                       //
      //deal out the cards                                             //
      for (var j = 0; j < players.length; j++) {                       // 94
        var playerId = players[j]._id;                                 // 95
        var cardId = deck[j];                                          // 96
        Players.update({ _id: playerId }, {                            // 97
          $set: { card: cardId }                                       // 98
        });                                                            //
      }                                                                //
                                                                       //
      //start the game                                                 //
      Games.update({ _id: gameId }, {                                  // 103
        $set: { stage: "Round 1" }                                     // 104
      });                                                              //
                                                                       //
      var updatedPlayers = Players.find({ game: gameId }).fetch();     // 107
                                                                       //
      return "Cards dealt";                                            // 109
                                                                       //
      function shuffle(array) {                                        // 112
        var currentIndex = array.length,                               // 113
            temporaryValue,                                            //
            randomIndex;                                               //
                                                                       //
        // While there remain elements to shuffle...                   //
        while (0 !== currentIndex) {                                   // 116
                                                                       //
          // Pick a remaining element...                               //
          randomIndex = Math.floor(Math.random() * currentIndex);      // 119
          currentIndex -= 1;                                           // 120
                                                                       //
          // And swap it with the current element.                     //
          temporaryValue = array[currentIndex];                        // 123
          array[currentIndex] = array[randomIndex];                    // 124
          array[randomIndex] = temporaryValue;                         // 125
        }                                                              //
                                                                       //
        return array;                                                  // 128
      }                                                                //
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=GameMethods.js.map
