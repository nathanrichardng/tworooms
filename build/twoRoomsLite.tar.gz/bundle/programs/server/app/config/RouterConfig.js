(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// config/RouterConfig.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Router.configure({                                                     // 1
	layoutTemplate: 'main',                                               // 2
	loadingTemplate: 'loading'                                            // 3
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=RouterConfig.js.map
