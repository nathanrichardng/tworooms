(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Card/CardHelpers.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
  // This code only runs on the client                                 //
  Template.card.helpers({                                              // 3
    card: function () {                                                // 4
      var playerId = Session.get("playerId");                          // 5
      var player = Players.findOne({ _id: playerId });                 // 6
      var cardId = player.card;                                        // 7
      return Cards.findOne({ _id: cardId });                           // 8
    },                                                                 //
    cardVisibility: function () {                                      // 10
      return Session.get("cardVisibility");                            // 11
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.card.events({                                               // 15
    "click .card": function (event) {                                  // 16
      event.preventDefault();                                          // 17
      if (Session.equals("cardVisibility", "hidden")) {                // 18
        Session.set("cardVisibility", "shown");                        // 19
      } else {                                                         //
        Session.set("cardVisibility", "hidden");                       // 22
      }                                                                //
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.cardsList.helpers({                                         // 27
    cards: function () {                                               // 28
      return Cards.find({ core: false });                              // 29
    },                                                                 //
    inDeckList: function (cardId) {                                    // 31
      var playerId = Session.get("playerId");                          // 32
      var player = Players.findOne({ _id: playerId });                 // 33
      var gameId = player.game;                                        // 34
      return Games.findOne({ _id: gameId, deckList: cardId });         // 35
    },                                                                 //
    slotsAvailable: function () {                                      // 37
      var playerId = Session.get("playerId");                          // 38
      var player = Players.findOne({ _id: playerId });                 // 39
      var gameId = player.game;                                        // 40
      var game = Games.findOne({ _id: gameId });                       // 41
      var slotsAvailable = game.players.length - 2 - game.deckList.length;
      if (slotsAvailable < 0) {                                        // 43
        slotsAvailable = 0;                                            // 44
      }                                                                //
      return slotsAvailable;                                           // 46
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.cardsList.events({                                          // 50
    "change [type=checkbox]": function (event) {                       // 51
      event.preventDefault();                                          // 52
      if (event.target.checked) {                                      // 53
        var playerId = Session.get("playerId");                        // 54
        var cardId = this._id;                                         // 55
        Meteor.call("addCardToDeckList", playerId, cardId, function (error, result) {
          if (result === "Not enough players") {                       // 57
            event.target.checked = false;                              // 58
            console.log("Not enough players");                         // 59
          }                                                            //
        });                                                            //
      } else if (!event.target.checked) {                              //
        var playerId = Session.get("playerId");                        // 64
        var cardId = this._id;                                         // 65
        Meteor.call("removeCardFromDeckList", playerId, cardId);       // 66
      }                                                                //
    }                                                                  //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=CardHelpers.js.map
