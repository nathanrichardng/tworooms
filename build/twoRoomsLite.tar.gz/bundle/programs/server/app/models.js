(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// models.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Cards = new Mongo.Collection("Cards");                                 // 1
Players = new Mongo.Collection("Players");                             // 2
Games = new Mongo.Collection("Games");                                 // 3
                                                                       //
var Schema = {};                                                       // 7
                                                                       //
Schema.Card = new SimpleSchema({                                       // 9
    name: {                                                            // 10
        type: String,                                                  // 11
        optional: false                                                // 12
    },                                                                 //
    description: {                                                     // 14
        type: String,                                                  // 15
        optional: true                                                 // 16
    },                                                                 //
    team: {                                                            // 18
        type: String,                                                  // 19
        optional: false                                                // 20
    },                                                                 //
    core: {                                                            // 22
        type: Boolean                                                  // 23
    }                                                                  //
});                                                                    //
                                                                       //
Schema.Player = new SimpleSchema({                                     // 27
    name: {                                                            // 28
        type: String,                                                  // 29
        optional: false                                                // 30
    },                                                                 //
    game: {                                                            // 32
        type: SimpleSchema.Game,                                       // 33
        optional: false                                                // 34
    },                                                                 //
    card: {                                                            // 36
        type: SimpleSchema.Card,                                       // 37
        optional: true                                                 // 38
    }                                                                  //
});                                                                    //
                                                                       //
Schema.Game = new SimpleSchema({                                       // 42
    players: {                                                         // 43
        type: [String],                                                // 44
        autoValue: function () {                                       // 45
            if (this.isInsert) {                                       // 46
                return [];                                             // 47
            }                                                          //
        }                                                              //
    },                                                                 //
    stage: {                                                           // 51
        type: String,                                                  // 52
        optional: false,                                               // 53
        allowedValues: ['Lobby', 'Round 1', 'Round 2', 'Round 3', 'Game Over']
    },                                                                 //
    createdOn: {                                                       // 56
        type: Date,                                                    // 57
        autoValue: function () {                                       // 58
            if (this.isInsert) {                                       // 59
                var createdOn = new Date();                            // 60
                return createdOn;                                      // 61
            }                                                          //
        }                                                              //
    },                                                                 //
    deckList: {                                                        // 65
        type: [String],                                                // 66
        autoValue: function () {                                       // 67
            if (this.isInsert) {                                       // 68
                return [];                                             // 69
            }                                                          //
        }                                                              //
    },                                                                 //
    timerLength: {                                                     // 73
        type: Number,                                                  // 74
        autoValue: function () {                                       // 75
            if (this.isInsert) {                                       // 76
                return 3;                                              // 77
            }                                                          //
        }                                                              //
    },                                                                 //
    timerEndTime: {                                                    // 81
        type: Date,                                                    // 82
        optional: true                                                 // 83
    },                                                                 //
    timerPaused: {                                                     // 85
        type: Boolean,                                                 // 86
        optional: true                                                 // 87
    },                                                                 //
    timerPausedTime: {                                                 // 89
        type: Date,                                                    // 90
        optional: true                                                 // 91
    }                                                                  //
    //create methods that set an end time, and retrieve the time remaining
});                                                                    //
                                                                       //
Cards.attachSchema(Schema.Card);                                       // 96
Players.attachSchema(Schema.Player);                                   // 97
Games.attachSchema(Schema.Game);                                       // 98
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=models.js.map
